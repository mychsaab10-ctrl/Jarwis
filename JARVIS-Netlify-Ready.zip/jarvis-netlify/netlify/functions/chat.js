'use strict';
exports.handler = async (event) => {
  const headers = {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
    'X-Content-Type-Options': 'nosniff'
  };
  const send = (statusCode, body) => ({ statusCode, headers, body: JSON.stringify(body) });
  if (event.httpMethod !== 'POST') return send(405, { error: 'Sirf POST request allowed hai.' });
  const API_KEY = process.env.GEMINI_API_KEY;
  const MODEL = process.env.GEMINI_MODEL || 'gemini-2.5-flash';
  if (!API_KEY || API_KEY === 'PASTE_YOUR_NEW_KEY_HERE') {
    return send(503, { error: 'Netlify mein GEMINI_API_KEY set nahi hai. Site settings mein environment variable add karein.' });
  }
  let body;
  try { body = JSON.parse(event.body || '{}'); }
  catch { return send(400, { error: 'Message format theek nahi.' }); }
  const message = typeof body.message === 'string' ? body.message.trim().slice(0, 6000) : '';
  if (!message) return send(400, { error: 'Message khali hai.' });
  const history = Array.isArray(body.history) ? body.history.slice(-18).map(x => ({
    role: x.role === 'model' || x.role === 'assistant' ? 'model' : 'user',
    parts: [{ text: String(x.text || '').slice(0, 4000) }]
  })).filter(x => x.parts[0].text) : [];
  const memories = Array.isArray(body.memories) ? body.memories.slice(-30).map(x => String(x).slice(0, 500)) : [];
  const system = `Tum JARVIS ho, ek madadgar, natural aur zimmedar AI assistant. User ko sirf Roman Urdu mein jawab do (Urdu alfaaz English letters mein), jab tak user specifically doosri zaban na mange. Friendly aur conversational raho; robotic ya har baar ek jaisa jawab na do. Pichhli conversation ko context mein rakho. User ki saved memory yeh hai: ${memories.length ? memories.join(' | ') : 'koi saved memory nahi'}. Apni capabilities ke bare mein sach bolo; aise actions karne ka dawa mat karo jo tumne waqai nahi kiye. User ke device, files, accounts ya internet par khud-ba-khud access nahi hai. Dangerous, illegal, ya privacy-violating requests mein munasib safety boundaries rakho. Jawab aam tor par mukhtasar magar useful ho.`;
  try {
    const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(MODEL)}:generateContent`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'x-goog-api-key': API_KEY },
      body: JSON.stringify({ systemInstruction: { parts: [{ text: system }] }, contents: [...history, { role: 'user', parts: [{ text: message }] }], generationConfig: { temperature: 0.8, maxOutputTokens: 900 } }),
      signal: AbortSignal.timeout(45000)
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) return send(response.status === 429 ? 429 : 502, { error: response.status === 429 ? 'AI service par limit hai. Thori dair baad try karein.' : 'Gemini API request fail hui. API key, model aur quota check karein.' });
    const reply = data.candidates?.[0]?.content?.parts?.map(p => p.text || '').join('').trim();
    if (!reply) return send(502, { error: 'AI se jawab nahi mila. Dobara try karein.' });
    return send(200, { reply, model: MODEL });
  } catch {
    return send(504, { error: 'AI service ka response time out ho gaya. Dobara koshish karein.' });
  }
};
