JARVIS ko Netlify par chalane ka asaan tareeqa

1) Is ZIP ko extract karein.
2) Is folder ke tamam files GitHub repository mein upload karein (ZIP file khud upload na karein; extract ki hui files upload karein).
3) Netlify mein apni site kholein. Site configuration / Environment variables (kabhi Site configuration > Environment variables) mein yeh add karein:
   Key: GEMINI_API_KEY
   Value: apni NEW Gemini API key
   Optional:
   Key: GEMINI_MODEL
   Value: gemini-2.5-flash
4) Save karein. Netlify par Deploys mein ja kar Trigger deploy > Clear cache and deploy site (ya latest deploy) karein.
5) Deploy complete hone ke baad website kholein, text box mein 'Assalam o alaikum JARVIS' likhein aur Send dabayein.
6) Jawab aaye to speaker/voice enabled rakhein. Mobile browser mein sound aur microphone permission check karein.

ZAROORI: Purani API key agar kabhi HTML mein lagi hui thi to usay revoke/delete karke NEW key use karein. API key kisi ko chat mein na bhejein.
